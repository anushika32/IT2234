const mongoose = require('mongoose')
const courseSchema = new mongoose.Schema({
    code: {type: String}, // Added missing code field
    name: {type: String},
    credits: {type: Number},
    description: {type: String}
});

const Course = mongoose.model('course',courseSchema)
const webservice = new Course({
    code:'IT2234',
    name:'Practical for webService',
    credits:3,
    description:'Build a REST API with NodeJs technology'
})
// Remove the test save (webservice.save())
module.exports=Course
